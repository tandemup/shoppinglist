import { joinText } from "./text";

export function formatCurrency(value, currency = "EUR", locale = "es-ES") {
  const amount = Number(value) || 0;

  return new Intl.NumberFormat(locale, {
    style: "currency",
    currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function priceText(value, unitFallback) {
  // 🟢 priceInfo moderno
  if (value && typeof value === "object") {
    const { unitPrice, total, qty, unit, currency = "EUR" } = value;

    let price = null;

    if (typeof unitPrice === "number") {
      price = unitPrice;
    } else if (
      typeof total === "number" &&
      typeof qty === "number" &&
      qty > 0
    ) {
      price = total / qty;
    } else if (typeof total === "number") {
      price = total;
    }

    if (price == null) return "";

    return joinText(
      formatCurrency(price, currency),
      (unit ?? unitFallback) && ` / ${unit ?? unitFallback}`
    );
  }

  // 🟡 modo legacy
  if (value == null) return "";

  return joinText(formatCurrency(value), unitFallback && ` / ${unitFallback}`);
}

export function metaText(frequency, date) {
  if (!frequency && !date) return "";

  const d = date ? new Date(date).toLocaleDateString("es-ES") : "—";
  return joinText(`${frequency} compras`, " · ", d);
}
