export const STORAGE_KEYS = {
  ACTIVE_LISTS: "active_lists",
  ARCHIVED_LISTS: "archived_lists",
  PURCHASE_HISTORY: "purchase_history",
  SCANNED_HISTORY: "scanned_history",
  CONFIG: "app_config",
};
