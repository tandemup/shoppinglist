GET /api/stores/city?city=Gijón
GET /api/stores/zipcode?zipcode=33204
GET /api/stores/nearby?lat=43.5369&lon=-5.6613
